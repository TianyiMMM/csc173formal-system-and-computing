
CSC173 Project4 Tianyi Ma
No collaborator

Use:
gcc -std=c99 -Wall -Werror -o project4 main.c LinkedList.c CSG.c SNAP.c CP.c CDH.c CR.c CRDH.c DH.c
to run my project in the terminal

Part 2 and 3 are tested first, and Part 1 at last, since Part1 alters the relations.

To test Part 2, input relevant info as prompted.  